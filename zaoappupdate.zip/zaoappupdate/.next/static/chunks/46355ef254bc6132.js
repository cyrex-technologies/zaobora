__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/68e1a36764bcd110.js",
  "static/chunks/turbopack-d63691b50e3b0b2a.js"
])
