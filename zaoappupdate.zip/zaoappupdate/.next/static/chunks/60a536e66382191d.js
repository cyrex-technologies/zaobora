__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/68e1a36764bcd110.js",
  "static/chunks/turbopack-a730133b53911882.js"
])
