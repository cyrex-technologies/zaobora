__turbopack_load_page_chunks__("/_app", [
  "static/chunks/7024f9e6f89a030c.js",
  "static/chunks/402d1c8e224d620b.js",
  "static/chunks/turbopack-c959f7f0bf588361.js"
])
