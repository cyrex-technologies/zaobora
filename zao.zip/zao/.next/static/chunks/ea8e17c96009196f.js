__turbopack_load_page_chunks__("/_error", [
  "static/chunks/9b88c6bc964d7fa0.js",
  "static/chunks/402d1c8e224d620b.js",
  "static/chunks/turbopack-453fe180ecec1f54.js"
])
