globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/7024f9e6f89a030c.js",
      "static/chunks/402d1c8e224d620b.js",
      "static/chunks/turbopack-c959f7f0bf588361.js"
    ],
    "/_error": [
      "static/chunks/9b88c6bc964d7fa0.js",
      "static/chunks/402d1c8e224d620b.js",
      "static/chunks/turbopack-453fe180ecec1f54.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/5132ebf2a416be1e.js",
    "static/chunks/230001cd6060cff4.js",
    "static/chunks/d606cfa869aa0bb2.js",
    "static/chunks/09a4507fb8f16ca2.js",
    "static/chunks/turbopack-bbea0056e2b39374.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];