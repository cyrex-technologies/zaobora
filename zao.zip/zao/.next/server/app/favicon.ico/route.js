var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__572a6839._.js")
R.c("server/chunks/bb76c_next_dist_41c5f96f._.js")
R.c("server/chunks/[root-of-the-server]__e44d662f._.js")
R.c("server/chunks/bb76c_next_dist_a3785245._.js")
R.c("server/chunks/bb76c_next_dist_42e99b86._.js")
R.m(54292)
R.m(47929)
module.exports=R.m(47929).exports
