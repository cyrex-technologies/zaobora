var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__64fd21b5._.js")
R.c("server/chunks/ssr/[root-of-the-server]__50fa0ff8._.js")
R.m(46372)
module.exports=R.m(46372).exports
