module.exports=[4924,a=>{"use strict";a.s(["default",()=>c]);var b=a.i(18746);function c({children:a}){return(0,b.jsx)("div",{className:"min-h-screen bg-white",children:a})}}];

//# sourceMappingURL=dev_zaobora_src_app_services_agrodealers_layout_tsx_ecbb1895._.js.map