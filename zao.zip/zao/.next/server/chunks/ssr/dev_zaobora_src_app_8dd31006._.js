module.exports=[98469,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},82802,a=>{"use strict";a.s(["default",()=>b]);let b={src:a.i(98469).default,width:256,height:256}}];

//# sourceMappingURL=dev_zaobora_src_app_8dd31006._.js.map