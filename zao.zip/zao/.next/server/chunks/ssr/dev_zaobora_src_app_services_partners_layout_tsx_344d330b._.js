module.exports=[72802,a=>{"use strict";a.s(["default",()=>c]);var b=a.i(18746);function c({children:a}){return(0,b.jsx)("div",{className:"min-h-screen bg-white",children:a})}}];

//# sourceMappingURL=dev_zaobora_src_app_services_partners_layout_tsx_344d330b._.js.map