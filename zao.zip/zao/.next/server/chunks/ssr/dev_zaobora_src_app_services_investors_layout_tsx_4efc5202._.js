module.exports=[99420,a=>{"use strict";a.s(["default",()=>c]);var b=a.i(18746);function c({children:a}){return(0,b.jsx)("div",{className:"min-h-screen bg-white",children:a})}}];

//# sourceMappingURL=dev_zaobora_src_app_services_investors_layout_tsx_4efc5202._.js.map